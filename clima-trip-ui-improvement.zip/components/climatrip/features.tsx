import { BarChart3, Heart, MapPin, Radar } from "lucide-react"

const features = [
  {
    icon: Radar,
    title: "Pronóstico en tiempo real",
    description: "Temperatura, humedad, viento y sensación térmica actualizados al instante para cualquier ciudad.",
  },
  {
    icon: MapPin,
    title: "Buscá cualquier destino",
    description: "Más de 12.000 ciudades disponibles con autocompletado inteligente y resultados en milisegundos.",
  },
  {
    icon: Heart,
    title: "Tus ciudades favoritas",
    description: "Guardá los destinos que más te importan y consultá su clima de un vistazo desde tu panel.",
  },
  {
    icon: BarChart3,
    title: "Estadísticas visuales",
    description: "Compará tendencias, máximas y mínimas con gráficos claros para planificar mejor tu viaje.",
  },
]

export function Features() {
  return (
    <section id="buscar" className="relative mx-auto max-w-6xl scroll-mt-20 px-5 py-20 lg:px-8">
      <div className="mx-auto max-w-2xl text-center">
        <span className="text-sm font-semibold uppercase tracking-wider text-primary">Todo en un solo lugar</span>
        <h2 className="mt-3 text-balance font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
          Herramientas pensadas para viajeros
        </h2>
        <p className="mt-4 text-pretty text-muted-foreground">
          ClimaTrip reúne todo lo que necesitás para anticiparte al clima de tus próximos destinos.
        </p>
      </div>

      <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {features.map((feature) => (
          <article
            key={feature.title}
            className="group relative overflow-hidden rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-sm transition-colors hover:border-primary/40"
          >
            <div className="absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
            <span className="flex size-11 items-center justify-center rounded-xl bg-primary/12 text-primary ring-1 ring-primary/20">
              <feature.icon className="size-5" />
            </span>
            <h3 className="mt-5 font-display text-lg font-semibold text-foreground">{feature.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{feature.description}</p>
          </article>
        ))}
      </div>
    </section>
  )
}
