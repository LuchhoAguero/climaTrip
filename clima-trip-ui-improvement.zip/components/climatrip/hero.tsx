import Image from "next/image"
import { ArrowRight, Cloud, CloudRain, Search, Snowflake, Sun } from "lucide-react"
import { Button } from "@/components/ui/button"
import { AuroraBackground } from "./aurora-background"

function WeatherChip({
  city,
  temp,
  icon: Icon,
  className,
  animation,
}: {
  city: string
  temp: string
  icon: React.ComponentType<{ className?: string }>
  className?: string
  animation?: string
}) {
  return (
    <div
      className={`absolute flex items-center gap-2.5 rounded-2xl border border-border/70 bg-card/70 px-3.5 py-2.5 shadow-2xl shadow-black/40 backdrop-blur-md ${animation ?? ""} ${className ?? ""}`}
    >
      <span className="flex size-8 items-center justify-center rounded-lg bg-primary/15 text-primary">
        <Icon className="size-4" />
      </span>
      <div className="leading-tight">
        <p className="text-xs text-muted-foreground">{city}</p>
        <p className="font-display text-sm font-semibold text-foreground">{temp}</p>
      </div>
    </div>
  )
}

export function Hero() {
  return (
    <section id="inicio" className="relative overflow-hidden pt-16">
      <AuroraBackground />
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-16 md:py-24 lg:grid-cols-[1.05fr_1fr] lg:gap-8 lg:px-8">
        {/* Copy */}
        <div className="relative z-10 text-center lg:text-left">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-primary">
            <span className="size-1.5 rounded-full bg-primary" />
            Explorador meteorológico
          </span>

          <h1 className="mt-6 text-balance font-display text-4xl font-bold leading-[1.05] tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            Conocé el clima de{" "}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              tu próximo destino
            </span>
          </h1>

          <p className="mx-auto mt-5 max-w-md text-pretty text-base leading-relaxed text-muted-foreground lg:mx-0 lg:text-lg">
            Buscá ciudades, consultá su pronóstico en tiempo real y organizá tus destinos favoritos en una sola
            aplicación.
          </p>

          <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row lg:justify-start">
            <Button
              size="lg"
              className="group h-12 w-full gap-2 px-6 text-base font-semibold sm:w-auto"
            >
              <Search className="size-4" />
              Buscar ciudades
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="h-12 w-full border-border bg-transparent px-6 text-base font-semibold hover:bg-secondary sm:w-auto"
            >
              Crear una cuenta
            </Button>
          </div>

          <div className="mt-8 flex items-center justify-center gap-6 lg:justify-start">
            <div className="text-center lg:text-left">
              <p className="font-display text-xl font-bold text-foreground">12k+</p>
              <p className="text-xs text-muted-foreground">Ciudades</p>
            </div>
            <div className="h-8 w-px bg-border" />
            <div className="text-center lg:text-left">
              <p className="font-display text-xl font-bold text-foreground">7 días</p>
              <p className="text-xs text-muted-foreground">De pronóstico</p>
            </div>
            <div className="h-8 w-px bg-border" />
            <div className="text-center lg:text-left">
              <p className="font-display text-xl font-bold text-foreground">Tiempo real</p>
              <p className="text-xs text-muted-foreground">Datos precisos</p>
            </div>
          </div>
        </div>

        {/* Illustration */}
        <div className="relative z-10 mx-auto aspect-square w-full max-w-md">
          {/* orbit rings */}
          <div className="animate-spin-slow absolute inset-0">
            <div className="absolute inset-[6%] rounded-full border border-border/40" />
            <div className="absolute inset-[18%] rounded-full border border-border/30" />
            <div className="absolute inset-[30%] rounded-full border border-border/20" />
          </div>

          {/* glow behind earth */}
          <div className="absolute inset-[16%] rounded-full bg-primary/25 blur-3xl" />

          {/* earth */}
          <div className="animate-float-slow absolute inset-[20%] overflow-hidden rounded-full shadow-2xl shadow-primary/20 ring-1 ring-primary/20">
            <Image
              src="/earth-hero.png"
              alt="Planeta Tierra visto desde el espacio con un halo azul"
              fill
              priority
              sizes="(max-width: 768px) 60vw, 22vw"
              className="object-cover"
            />
          </div>

          {/* weather chips */}
          <WeatherChip
            city="Buenos Aires"
            temp="22°C"
            icon={Sun}
            animation="animate-float-slow"
            className="right-0 top-[10%]"
          />
          <WeatherChip
            city="Londres"
            temp="14°C"
            icon={CloudRain}
            animation="animate-float-slower"
            className="left-[-6%] top-[46%]"
          />
          <WeatherChip
            city="Oslo"
            temp="-3°C"
            icon={Snowflake}
            animation="animate-float-slow"
            className="bottom-[8%] right-[8%] [animation-delay:-2s]"
          />
          <WeatherChip
            city="Tokio"
            temp="19°C"
            icon={Cloud}
            animation="animate-float-slower"
            className="bottom-[24%] left-[2%] [animation-delay:-3s]"
          />
        </div>
      </div>
    </section>
  )
}
