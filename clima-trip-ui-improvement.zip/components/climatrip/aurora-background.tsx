export function AuroraBackground() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
      {/* base grid glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_-10%,color-mix(in_oklch,var(--color-primary)_35%,transparent),transparent_70%)]" />
      {/* aurora blobs */}
      <div className="animate-aurora absolute -left-24 top-10 size-[38rem] rounded-full bg-aurora-1/40 blur-[110px]" />
      <div className="animate-aurora absolute right-[-8rem] top-40 size-[34rem] rounded-full bg-aurora-2/30 blur-[120px] [animation-delay:-4s]" />
      <div className="animate-aurora absolute bottom-[-10rem] left-1/3 size-[32rem] rounded-full bg-aurora-3/30 blur-[120px] [animation-delay:-8s]" />
      {/* subtle dotted texture */}
      <div className="absolute inset-0 opacity-[0.05] [background-image:radial-gradient(currentColor_1px,transparent_1px)] [background-size:22px_22px] text-foreground" />
    </div>
  )
}
