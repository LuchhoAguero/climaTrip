import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export function CtaBanner() {
  return (
    <section id="stats" className="relative mx-auto max-w-6xl scroll-mt-20 px-5 py-16 lg:px-8">
      <div className="relative overflow-hidden rounded-3xl border border-primary/25 bg-gradient-to-br from-card to-background px-6 py-14 text-center sm:px-12">
        <div
          aria-hidden
          className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_60%_80%_at_50%_0%,color-mix(in_oklch,var(--color-primary)_25%,transparent),transparent_70%)]"
        />
        <h2 className="mx-auto max-w-2xl text-balance font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
          Planificá tu próximo viaje con confianza
        </h2>
        <p className="mx-auto mt-4 max-w-lg text-pretty text-muted-foreground">
          Creá tu cuenta gratis y empezá a seguir el clima de todos los destinos que te interesan.
        </p>
        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Button size="lg" className="group h-12 w-full gap-2 px-7 text-base font-semibold sm:w-auto">
            Crear cuenta gratis
            <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="h-12 w-full border-border bg-transparent px-7 text-base font-semibold hover:bg-secondary sm:w-auto"
          >
            Explorar el mapa
          </Button>
        </div>
      </div>
    </section>
  )
}
