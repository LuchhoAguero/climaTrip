import { Search, Star, TrendingUp } from "lucide-react"

const steps = [
  {
    icon: Search,
    step: "01",
    title: "Buscá tu destino",
    description: "Escribí el nombre de cualquier ciudad y elegí entre los resultados sugeridos al instante.",
  },
  {
    icon: TrendingUp,
    step: "02",
    title: "Consultá el pronóstico",
    description: "Revisá el clima actual y la previsión de los próximos 7 días con datos detallados.",
  },
  {
    icon: Star,
    step: "03",
    title: "Guardá tus favoritos",
    description: "Agregá las ciudades a tu panel para seguirlas y compararlas cuando quieras.",
  },
]

export function HowItWorks() {
  return (
    <section className="relative mx-auto max-w-6xl px-5 py-20 lg:px-8">
      <div className="mx-auto max-w-2xl text-center">
        <span className="text-sm font-semibold uppercase tracking-wider text-primary">Cómo funciona</span>
        <h2 className="mt-3 text-balance font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
          Empezá en tres pasos simples
        </h2>
      </div>

      <div className="relative mt-14 grid gap-8 md:grid-cols-3">
        <div className="absolute left-0 right-0 top-6 hidden h-px bg-gradient-to-r from-transparent via-border to-transparent md:block" />
        {steps.map((s) => (
          <div key={s.step} className="relative text-center">
            <div className="relative mx-auto flex size-14 items-center justify-center rounded-2xl border border-primary/25 bg-card text-primary">
              <s.icon className="size-6" />
              <span className="absolute -right-2 -top-2 flex size-6 items-center justify-center rounded-full bg-primary text-[11px] font-bold text-primary-foreground">
                {s.step}
              </span>
            </div>
            <h3 className="mt-6 font-display text-lg font-semibold text-foreground">{s.title}</h3>
            <p className="mx-auto mt-2 max-w-xs text-sm leading-relaxed text-muted-foreground">{s.description}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
