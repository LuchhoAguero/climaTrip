import { CloudSun } from "lucide-react"

const columns = [
  {
    title: "Producto",
    links: ["Buscar ciudades", "Mis ciudades", "Estadísticas", "Mapa del clima"],
  },
  {
    title: "Recursos",
    links: ["Ayuda", "Guías de viaje", "API del clima", "Estado del servicio"],
  },
  {
    title: "Empresa",
    links: ["Sobre nosotros", "Blog", "Contacto", "Privacidad"],
  },
]

export function Footer() {
  return (
    <footer className="border-t border-border/60 bg-card/30">
      <div className="mx-auto max-w-6xl px-5 py-14 lg:px-8">
        <div className="grid gap-10 md:grid-cols-[1.5fr_1fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="flex size-9 items-center justify-center rounded-xl bg-primary/15 text-primary ring-1 ring-primary/25">
                <CloudSun className="size-5" />
              </span>
              <span className="font-display text-lg font-bold tracking-tight text-foreground">
                Clima<span className="text-primary">Trip</span>
              </span>
            </div>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
              El clima de tu próximo destino, siempre a un clic de distancia.
            </p>
          </div>

          {columns.map((col) => (
            <div key={col.title}>
              <h3 className="text-sm font-semibold text-foreground">{col.title}</h3>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm text-muted-foreground transition-colors hover:text-primary">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-border/60 pt-6 sm:flex-row">
          <p className="text-sm text-muted-foreground">© {new Date().getFullYear()} ClimaTrip. Todos los derechos reservados.</p>
          <p className="text-sm text-muted-foreground">Hecho para viajeros curiosos.</p>
        </div>
      </div>
    </footer>
  )
}
