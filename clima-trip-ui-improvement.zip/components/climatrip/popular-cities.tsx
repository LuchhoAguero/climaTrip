import { CloudRain, CloudSun, Droplets, Snowflake, Sun, Wind } from "lucide-react"

const cities = [
  {
    city: "Buenos Aires",
    country: "Argentina",
    temp: "22°",
    condition: "Soleado",
    icon: Sun,
    humidity: "48%",
    wind: "12 km/h",
  },
  {
    city: "Londres",
    country: "Reino Unido",
    temp: "14°",
    condition: "Lluvia ligera",
    icon: CloudRain,
    humidity: "82%",
    wind: "20 km/h",
  },
  {
    city: "Oslo",
    country: "Noruega",
    temp: "-3°",
    condition: "Nevando",
    icon: Snowflake,
    humidity: "70%",
    wind: "9 km/h",
  },
  {
    city: "Tokio",
    country: "Japón",
    temp: "19°",
    condition: "Parcialmente nublado",
    icon: CloudSun,
    humidity: "55%",
    wind: "14 km/h",
  },
]

export function PopularCities() {
  return (
    <section id="ciudades" className="relative scroll-mt-20 border-y border-border/60 bg-card/30 py-20">
      <div className="mx-auto max-w-6xl px-5 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <span className="text-sm font-semibold uppercase tracking-wider text-primary">Tendencia</span>
            <h2 className="mt-3 text-balance font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Ciudades populares ahora
            </h2>
          </div>
          <a href="#buscar" className="text-sm font-medium text-primary hover:underline">
            Ver todas las ciudades
          </a>
        </div>

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {cities.map((c) => (
            <article
              key={c.city}
              className="group relative overflow-hidden rounded-2xl border border-border bg-background/60 p-5 backdrop-blur-sm transition-all hover:-translate-y-1 hover:border-primary/40 hover:shadow-xl hover:shadow-primary/5"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-display text-base font-semibold text-foreground">{c.city}</h3>
                  <p className="text-xs text-muted-foreground">{c.country}</p>
                </div>
                <span className="flex size-10 items-center justify-center rounded-xl bg-primary/12 text-primary ring-1 ring-primary/20">
                  <c.icon className="size-5" />
                </span>
              </div>

              <div className="mt-6 flex items-end gap-2">
                <span className="font-display text-4xl font-bold text-foreground">{c.temp}</span>
                <span className="pb-1.5 text-sm text-muted-foreground">{c.condition}</span>
              </div>

              <div className="mt-5 flex items-center gap-4 border-t border-border/60 pt-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <Droplets className="size-3.5 text-accent" />
                  {c.humidity}
                </span>
                <span className="flex items-center gap-1.5">
                  <Wind className="size-3.5 text-accent" />
                  {c.wind}
                </span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
