import { Navbar } from "@/components/climatrip/navbar"
import { Hero } from "@/components/climatrip/hero"
import { Features } from "@/components/climatrip/features"
import { PopularCities } from "@/components/climatrip/popular-cities"
import { HowItWorks } from "@/components/climatrip/how-it-works"
import { CtaBanner } from "@/components/climatrip/cta"
import { Footer } from "@/components/climatrip/footer"

export default function Page() {
  return (
    <main className="relative min-h-screen bg-background">
      <Navbar />
      <Hero />
      <Features />
      <PopularCities />
      <HowItWorks />
      <CtaBanner />
      <Footer />
    </main>
  )
}
